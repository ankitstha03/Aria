from django.shortcuts import render, redirect
from django import forms
from django.http import HttpResponse
from django.core.urlresolvers import reverse
from authentication.models import UserProfiles
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from django.http import HttpResponseRedirect
# This line imports the Django forms package

g_choice= [
    ('male', 'Male'),
    ('female', 'Female'),
    ('other', 'Other'),
    ]
class Form_inscription(forms.Form):
	# name     = forms.CharField(label="Name", max_length=30, error_messages=error_name)
    name = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'First Name'}), max_length=30)
    lstname = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'Last Name'}), max_length=30)
    login = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'Username'}))
    email = forms.EmailField(widget=forms.TextInput(attrs={'placeholder': 'E-mail'}))
    password = forms.CharField(widget=forms.PasswordInput(attrs={'placeholder': 'Password'}))
    gender= forms.CharField(widget=forms.RadioSelect(choices=g_choice))
    # We add another field for the password. This field will be used to avoid typos from the user. If both passwords do not match, the validation will display an error message
    password_bis = forms.CharField(widget=forms.PasswordInput(attrs={'placeholder': 'Confirm Password'}))
    username = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'Username'}))
    password2 = forms.CharField(widget=forms.PasswordInput(attrs={'placeholder': 'Password'}))



    def clean(self):
        cleaned_data = super(Form_inscription, self).clean()
        password = self.cleaned_data.get('cpswd')
        password_bis = self.cleaned_data.get('conpswd')
        if password and password_bis and password != password_bis:
            raise forms.ValidationError("Passwords are not identical.")
        username = self.cleaned_data.get('username')
        password2 = self.cleaned_data.get('password2')
        if not authenticate(username=username, password=password2):
            raise forms.ValidationError("Wrong login or passwsord")
        return self.cleaned_data


def page(request):

    if 'btn1' in request.POST:
        form = Form_inscription(request.POST)
        if form.is_valid():
            name = form.cleaned_data['name']
            lstname = form.cleaned_data['lstname']
            login = form.cleaned_data['lstname']
            password = form.cleaned_data['password']
            email = form.cleaned_data['email']
            new_user = User.objects.create_user(username=login, email=email, password=password, first_name=name, last_name=lstname)
            new_user.is_active = True
            new_user.save()
            user = UserProfiles(user=new_user)
            user.save()
            return HttpResponse("User Created")
        else:
            return render(request, 'en/public/LOGIN.html', {'form' : form})
    elif 'btn2' in request.POST:
        form = Form_inscription(request.POST)
        if form.is_valid():
            username = form.cleaned_data["username"]
            password2 = form.cleaned_data["password2"]
            user = authenticate(username=username, password=password2)
            # This line verifies that the username exists and the password is correct.
            if user:
                login(request, user)
    # In this line, the login() function allows the user to connect.
                if request.GET.get('next') is not None:
                    return redirect(request.GET['next'])
        else:
            return render(request, 'en/public/LOGIN.html', {'form' : form})

    else:
        form = Form_inscription()
        return render(request, 'en/public/LOGIN.html', {'form' : form})
